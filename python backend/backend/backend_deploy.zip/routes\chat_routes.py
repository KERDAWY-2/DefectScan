from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from database import get_db
import models, auth
from typing import List, Dict
from pydantic import BaseModel
from datetime import datetime
import json

router = APIRouter(prefix="/chat", tags=["Chat"])

class MessageOut(BaseModel):
    id: int
    user_id: int
    sender_id: int
    content: str
    timestamp: datetime

    class Config:
        from_attributes = True

class ConnectionManager:
    def __init__(self):
        # Maps user_id to a list of active websockets (the user and possibly an admin)
        self.active_connections: Dict[int, List[WebSocket]] = {}

    async def connect(self, websocket: WebSocket, user_id: int):
        await websocket.accept()
        if user_id not in self.active_connections:
            self.active_connections[user_id] = []
        self.active_connections[user_id].append(websocket)

    def disconnect(self, websocket: WebSocket, user_id: int):
        if user_id in self.active_connections:
            if websocket in self.active_connections[user_id]:
                self.active_connections[user_id].remove(websocket)
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]

    async def broadcast(self, message: str, user_id: int):
        if user_id in self.active_connections:
            for connection in self.active_connections[user_id]:
                await connection.send_text(message)

manager = ConnectionManager()

def get_current_user_ws(token: str, db: Session):
    try:
        from jose import jwt
        from auth import SECRET_KEY, ALGORITHM
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = payload.get("sub")
        if user_id is None:
            return None
        user = db.query(models.User).filter(models.User.id == int(user_id)).first()
        return user
    except Exception:
        return None

@router.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: int, token: str = Query(...), db: Session = Depends(get_db)):
    user = get_current_user_ws(token, db)
    if not user:
        await websocket.close(code=1008)
        return
    
    # Only admins or the owner of the chat can connect to this specific user_id's room
    if user.role != "admin" and user.id != user_id:
        await websocket.close(code=1008)
        return

    await manager.connect(websocket, user_id)
    try:
        while True:
            data = await websocket.receive_text()
            
            # Save to DB
            msg = models.Message(user_id=user_id, sender_id=user.id, content=data)
            db.add(msg)
            db.commit()
            db.refresh(msg)
            
            # Broadcast the message to everyone in the room
            payload = {
                "id": msg.id,
                "user_id": msg.user_id,
                "sender_id": msg.sender_id,
                "content": msg.content,
                "timestamp": msg.timestamp.isoformat()
            }
            await manager.broadcast(json.dumps(payload), user_id)
            
    except WebSocketDisconnect:
        manager.disconnect(websocket, user_id)

@router.get("/history/{user_id}", response_model=List[MessageOut])
def get_history(user_id: int, db: Session = Depends(get_db), current_user: models.User = Depends(auth.get_current_user)):
    if current_user.role != "admin" and current_user.id != user_id:
        raise HTTPException(status_code=403, detail="Not authorized to view this chat history")
    return db.query(models.Message).filter(models.Message.user_id == user_id).order_by(models.Message.timestamp.asc()).all()
