import base64
import io

import cv2
import numpy as np
import torch
from torchvision import transforms
from fastapi import APIRouter, Depends, File, HTTPException, Request, UploadFile
from PIL import Image, ImageOps

from auth import get_current_user

router = APIRouter(prefix="/predict", tags=["Predict"])

DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
IMG_SIZE = 384
MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]
CONF_THRESHOLD = 0.5

val_tf = transforms.Compose([
    transforms.Resize(IMG_SIZE + 32),
    transforms.CenterCrop(IMG_SIZE),
    transforms.ToTensor(),
    transforms.Normalize(MEAN, STD),
])

@router.post("/")
async def predict(
    request: Request,
    file: UploadFile = File(...),
    current_user=Depends(get_current_user),
):
    model = getattr(request.app.state, "model", None)
    cam = getattr(request.app.state, "cam", None)
    classes = getattr(request.app.state, "classes", [])

    if model is None or cam is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    raw_bytes = await file.read()
    if not raw_bytes:
        raise HTTPException(status_code=400, detail="Empty upload")

    try:
        img = Image.open(io.BytesIO(raw_bytes))
        img = ImageOps.exif_transpose(img).convert("RGB")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid image: {e}")

    # Prepare input tensor
    x = val_tf(img).unsqueeze(0).to(DEVICE)
    
    # Run inference
    with torch.no_grad():
        logits = model(x)
        probs = torch.sigmoid(logits)[0].cpu().numpy()

    top_idx = int(np.argmax(probs))
    top_prob = probs[top_idx]
    
    # Collect all predictions above threshold
    detections = []
    for i, p in enumerate(probs):
        if p > CONF_THRESHOLD:
            detections.append(f"{classes[i]} ({p:.2f})")
    
    num_detections = len(detections)
    if num_detections == 0:
        # If nothing is above threshold, we consider it a clean background with no defects
        text = "No defects detected."
        
        # We don't need to run Grad-CAM or draw boxes for a clean background
        # Just convert original image to base64 to send it back clean
        img_bgr = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
        ok, buf = cv2.imencode(".jpg", img_bgr, [cv2.IMWRITE_JPEG_QUALITY, 85])
        image_b64 = base64.b64encode(buf.tobytes()).decode("ascii") if ok else None

        print(
            f"[predict] user={getattr(current_user, 'username', '?')} "
            f"img={img.size} -> shown={text}"
        )

        return {
            "result": text,
            "image_b64": image_b64,
            "num_detections": 0,
        }

    text = ", ".join(detections)

    # Run Grad-CAM on the top predicted class
    from pytorch_grad_cam.utils.model_targets import ClassifierOutputTarget
    from pytorch_grad_cam.utils.image import show_cam_on_image
    
    heat = cam(input_tensor=x, targets=[ClassifierOutputTarget(top_idx)])[0]
    
    # Prepare image for overlay
    rgb = np.array(img.resize((IMG_SIZE, IMG_SIZE))).astype(np.float32) / 255.0
    overlay = show_cam_on_image(rgb, heat, use_rgb=True)
    
    # Convert overlay back to BGR for cv2 encoding
    img_bgr = cv2.cvtColor((overlay * 255).astype(np.uint8), cv2.COLOR_RGB2BGR)
    
    # Add text banner at the top
    label = f"{classes[top_idx]} ({top_prob:.2f})"
    (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
    cv2.rectangle(img_bgr, (5, 5), (5 + tw + 10, 5 + th + 15), (0, 0, 0), -1)
    cv2.putText(img_bgr, label, (10, 5 + th + 5), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

    ok, buf = cv2.imencode(".jpg", img_bgr, [cv2.IMWRITE_JPEG_QUALITY, 85])
    image_b64 = base64.b64encode(buf.tobytes()).decode("ascii") if ok else None

    print(
        f"[predict] user={getattr(current_user, 'username', '?')} "
        f"img={img.size} -> shown={text}"
    )

    return {
        "result": text,
        "image_b64": image_b64,
        "num_detections": num_detections,
    }

