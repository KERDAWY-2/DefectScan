from fastapi import APIRouter, UploadFile, File, Depends
from auth import get_current_user  # your existing auth dependency
import numpy as np
from PIL import Image
import io

router = APIRouter(prefix="/predict", tags=["Predict"])

# Load model once at startup
# model = load_your_model_here()

@router.post("/")
async def predict(file: UploadFile = File(...), current_user=Depends(get_current_user)):
    # Read image
    contents = await file.read()
    image = Image.open(io.BytesIO(contents)).resize((224, 224))
    img_array = np.array(image) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    # prediction = model.predict(img_array)
    # result = class_names[np.argmax(prediction)]

    return {"result": "model not loaded yet"}
